<?php

namespace Pusher\Actions;

class PluginWasUnlinked
{
}
