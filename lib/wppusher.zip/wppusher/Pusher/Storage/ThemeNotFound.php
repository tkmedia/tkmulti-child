<?php

namespace Pusher\Storage;

use Exception;

class ThemeNotFound extends Exception
{
}
